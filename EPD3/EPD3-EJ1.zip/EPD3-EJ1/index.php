<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        function fibonacci($limite){
            
            $j=0;
            $i = 1;
            
            for($pos=0;$i+$j<$limite;$pos++){
                $resultado[$pos] = $i + $j;
                $i = $j;
                $j = $resultado[$pos];
            }   
            
            return $resultado;
        }
        
        
        function imprimir($numeros){
            $resultado="<table border =1>";
            
            foreach($numeros as $i){
                $resultado.="<tr>";
                $resultado.='<td>' .$i.'</td>';
                $resultado.="</tr>";
            }
            $resultado.="</table>";
            return $resultado;
        }
        
        
            $limite = 10000;
        
            $resultado= fibonacci($limite);
            
            echo imprimir($resultado)
        
        
        ?>
    </body>
</html>
